const wordList = [
    {
        word: "pku",
        hint: "Let's play a Hangman Game. Guess the disease name."
    },
];