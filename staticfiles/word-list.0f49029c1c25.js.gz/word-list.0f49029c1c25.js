const wordList = [
    {
        word: "pku",
        hint: "What is the name of the disease due to Phenylalanine Hydroxylase deficiency?"
    },
    {
        word: "psip503",
        hint: "Which vector can be used for the transformation of L. plantarum cells?"
    },
    {
        word: "ncoi",
        hint: "Which restriction enzyme can be used for the preparation of engineered PHA?"
    },
];
