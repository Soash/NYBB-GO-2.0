const wordList = [
    {
        word: "pku",
        hint: "1: What is the name of the disease due to Phenylalanine Hydroxylase deficiency?"
    },
    // {
    //     word: "capsule",
    //     hint: "2: Outermost layer of L. plantarum bacteria."
    // },
    // {
    //     word: "psip503",
    //     hint: "3: Which vector can be used for the transformation of L. plantarum cells?"
    // },
    // {
    //     word: "subcloning",
    //     hint: "4: Moving a particular DNA sequence from a parent vector to a destination vector."
    // },
    // {
    //     word: "magnesium",
    //     hint: "5: Most common cofactor required by XhoI"
    // },
    // {
    //     word: "ert",
    //     hint: "6: A therapy replacing deficient enzymes in the body."
    // },
];
